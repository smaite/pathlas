
<?php $__env->startSection('title', 'Bookings'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <form action="<?php echo e(route('bookings.index')); ?>" method="GET" class="flex gap-3">
        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search..." class="px-4 py-2 border border-gray-200 rounded-xl w-48">
        <select name="status" class="px-4 py-2 border border-gray-200 rounded-xl">
            <option value="">All Status</option>
            <?php $__currentLoopData = ['pending', 'sample_collected', 'in_progress', 'completed', 'cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s); ?>" <?php echo e(request('status') == $s ? 'selected' : ''); ?>><?php echo e(ucfirst(str_replace('_', ' ', $s))); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit" class="px-4 py-2 bg-gray-100 rounded-xl hover:bg-gray-200">Filter</button>
    </form>
    <a href="<?php echo e(route('bookings.create')); ?>" class="px-4 py-2 bg-primary-600 text-white rounded-xl font-medium hover:bg-primary-700">New Booking</a>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Booking ID</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Patient</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Tests</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Amount</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Payment</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 font-mono text-sm"><?php echo e($booking->booking_id); ?></td>
                <td class="px-6 py-4">
                    <p class="font-medium"><?php echo e($booking->patient->name); ?></p>
                    <p class="text-sm text-gray-500"><?php echo e($booking->patient->phone); ?></p>
                </td>
                <td class="px-6 py-4 text-sm"><?php echo e($booking->bookingTests->count()); ?> tests</td>
                <td class="px-6 py-4 font-medium">₹<?php echo e(number_format($booking->total_amount, 2)); ?></td>
                <td class="px-6 py-4"><span class="px-2.5 py-1 rounded-full text-xs font-medium <?php echo e($booking->status_badge); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $booking->status))); ?></span></td>
                <td class="px-6 py-4"><span class="px-2.5 py-1 rounded-full text-xs font-medium <?php echo e($booking->payment_status == 'paid' ? 'bg-green-100 text-green-700' : ($booking->payment_status == 'partial' ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700')); ?>"><?php echo e(ucfirst($booking->payment_status)); ?></span></td>
                <td class="px-6 py-4">
                    <a href="<?php echo e(route('bookings.show', $booking)); ?>" class="px-3 py-1.5 bg-gray-100 text-gray-700 text-sm rounded-lg hover:bg-gray-200">View</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="7" class="px-6 py-8 text-center text-gray-500">No bookings found</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-6"><?php echo e($bookings->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\pathlas\resources\views/bookings/index.blade.php ENDPATH**/ ?>