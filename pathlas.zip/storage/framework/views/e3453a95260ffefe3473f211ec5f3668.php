
<?php $__env->startSection('title', 'Booking: ' . $booking->booking_id); ?>
<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="lg:col-span-2 space-y-6">
        <!-- Booking Info -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <div class="flex justify-between items-start mb-6">
                <div>
                    <h2 class="text-xl font-bold"><?php echo e($booking->booking_id); ?></h2>
                    <p class="text-gray-500"><?php echo e($booking->created_at->format('M d, Y h:i A')); ?></p>
                </div>
                <span class="px-3 py-1.5 rounded-full text-sm font-medium <?php echo e($booking->status_badge); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $booking->status))); ?></span>
            </div>
            
            <div class="grid grid-cols-2 gap-4 mb-6">
                <div>
                    <p class="text-sm text-gray-500">Patient</p>
                    <p class="font-medium"><?php echo e($booking->patient->name); ?></p>
                    <p class="text-sm text-gray-600"><?php echo e($booking->patient->phone); ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Created By</p>
                    <p class="font-medium"><?php echo e($booking->createdBy?->name ?? 'N/A'); ?></p>
                </div>
            </div>

            <?php if($booking->status === 'pending'): ?>
            <form action="<?php echo e(route('bookings.status', $booking)); ?>" method="POST" class="inline">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="status" value="sample_collected">
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700">Mark Sample Collected</button>
            </form>
            <?php endif; ?>
        </div>

        <!-- Tests -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-100"><h3 class="font-semibold">Tests & Results</h3></div>
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Test</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Result</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Normal Range</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    <?php $__currentLoopData = $booking->bookingTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4">
                            <p class="font-medium"><?php echo e($bt->test->name); ?></p>
                            <p class="text-sm text-gray-500"><?php echo e($bt->test->category->name ?? ''); ?></p>
                        </td>
                        <td class="px-6 py-4">
                            <?php if($bt->result && $bt->result->value): ?>
                            <span class="font-mono"><?php echo e($bt->result->value); ?> <?php echo e($bt->test->unit); ?></span>
                            <?php if($bt->result->flag && $bt->result->flag !== 'normal'): ?>
                            <span class="ml-2 px-2 py-0.5 rounded text-xs font-bold <?php echo e($bt->result->flag_badge); ?>"><?php echo e($bt->result->flag_label); ?></span>
                            <?php endif; ?>
                            <?php else: ?>
                            <span class="text-gray-400">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($bt->test->normal_range); ?></td>
                        <td class="px-6 py-4"><span class="px-2 py-1 rounded text-xs <?php echo e($bt->status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'); ?>"><?php echo e(ucfirst($bt->status)); ?></span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <?php if($booking->status === 'completed' && $booking->report): ?>
        <div class="bg-green-50 border border-green-200 rounded-2xl p-6">
            <div class="flex justify-between items-center">
                <div>
                    <h3 class="font-semibold text-green-800">Report Generated</h3>
                    <p class="text-sm text-green-600"><?php echo e($booking->report->report_id); ?></p>
                </div>
                <a href="<?php echo e(route('reports.download', $booking->report)); ?>" class="px-4 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700">Download PDF</a>
            </div>
        </div>
        <?php elseif($booking->status === 'completed'): ?>
        <a href="<?php echo e(route('reports.generate', $booking)); ?>" class="block bg-primary-50 border border-primary-200 rounded-2xl p-6 text-center hover:bg-primary-100">
            <p class="font-semibold text-primary-700">Generate Report</p>
        </a>
        <?php endif; ?>
    </div>

    <!-- Sidebar -->
    <div class="space-y-6">
        <!-- Payment Summary -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h3 class="font-semibold mb-4">Payment Summary</h3>
            <div class="space-y-2 mb-4">
                <div class="flex justify-between"><span class="text-gray-600">Subtotal</span><span>₹<?php echo e(number_format($booking->subtotal, 2)); ?></span></div>
                <div class="flex justify-between"><span class="text-gray-600">Discount</span><span class="text-red-600">-₹<?php echo e(number_format($booking->discount, 2)); ?></span></div>
                <div class="flex justify-between font-bold text-lg pt-2 border-t"><span>Total</span><span>₹<?php echo e(number_format($booking->total_amount, 2)); ?></span></div>
                <div class="flex justify-between"><span class="text-gray-600">Paid</span><span class="text-green-600">₹<?php echo e(number_format($booking->paid_amount, 2)); ?></span></div>
                <div class="flex justify-between font-medium"><span>Due</span><span class="text-red-600">₹<?php echo e(number_format($booking->due_amount, 2)); ?></span></div>
            </div>

            <?php if($booking->due_amount > 0): ?>
            <form action="<?php echo e(route('bookings.payment', $booking)); ?>" method="POST" class="space-y-3">
                <?php echo csrf_field(); ?>
                <input type="number" name="amount" step="0.01" max="<?php echo e($booking->due_amount); ?>" required placeholder="Amount" class="w-full px-4 py-2 border border-gray-200 rounded-xl">
                <select name="method" required class="w-full px-4 py-2 border border-gray-200 rounded-xl">
                    <option value="cash">Cash</option>
                    <option value="card">Card</option>
                    <option value="upi">UPI</option>
                </select>
                <button type="submit" class="w-full px-4 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700">Record Payment</button>
            </form>
            <?php endif; ?>
        </div>

        <!-- Actions -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h3 class="font-semibold mb-4">Actions</h3>
            <div class="space-y-2">
                <a href="<?php echo e(route('bookings.invoice', $booking)); ?>" class="block w-full px-4 py-2 bg-gray-100 text-gray-700 rounded-xl text-center hover:bg-gray-200">View Invoice</a>
                <a href="<?php echo e(route('bookings.invoice.pdf', $booking)); ?>" class="block w-full px-4 py-2 bg-gray-100 text-gray-700 rounded-xl text-center hover:bg-gray-200">Download Invoice PDF</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\pathlas\resources\views/bookings/show.blade.php ENDPATH**/ ?>