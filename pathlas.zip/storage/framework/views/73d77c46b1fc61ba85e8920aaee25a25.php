
<?php $__env->startSection('title', 'Edit Test'); ?>
<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
        <h2 class="text-xl font-semibold mb-6">Edit: <?php echo e($test->name); ?></h2>
        <form action="<?php echo e(route('tests.update', $test)); ?>" method="POST" class="space-y-6">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Test Name *</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $test->name)); ?>" required class="w-full px-4 py-3 border border-gray-200 rounded-xl">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Test Code *</label>
                    <input type="text" name="code" value="<?php echo e(old('code', $test->code)); ?>" required class="w-full px-4 py-3 border border-gray-200 rounded-xl">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Category *</label>
                    <select name="category_id" required class="w-full px-4 py-3 border border-gray-200 rounded-xl">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e($test->category_id == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Price (₹) *</label>
                    <input type="number" name="price" value="<?php echo e(old('price', $test->price)); ?>" step="0.01" required class="w-full px-4 py-3 border border-gray-200 rounded-xl">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Unit</label>
                    <input type="text" name="unit" value="<?php echo e(old('unit', $test->unit)); ?>" class="w-full px-4 py-3 border border-gray-200 rounded-xl">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Normal Min</label>
                    <input type="number" name="normal_min" value="<?php echo e(old('normal_min', $test->normal_min)); ?>" step="0.01" class="w-full px-4 py-3 border border-gray-200 rounded-xl">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Normal Max</label>
                    <input type="number" name="normal_max" value="<?php echo e(old('normal_max', $test->normal_max)); ?>" step="0.01" class="w-full px-4 py-3 border border-gray-200 rounded-xl">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Sample Type</label>
                    <select name="sample_type" class="w-full px-4 py-3 border border-gray-200 rounded-xl">
                        <?php $__currentLoopData = ['blood', 'urine', 'stool', 'swab', 'other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type); ?>" <?php echo e($test->sample_type == $type ? 'selected' : ''); ?>><?php echo e(ucfirst($type)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="flex items-center">
                    <label class="flex items-center space-x-3">
                        <input type="checkbox" name="is_active" value="1" <?php echo e($test->is_active ? 'checked' : ''); ?> class="w-5 h-5 text-primary-600 rounded">
                        <span class="font-medium">Active</span>
                    </label>
                </div>
            </div>
            <div class="flex gap-4">
                <button type="submit" class="px-6 py-3 bg-primary-600 text-white rounded-xl font-medium hover:bg-primary-700">Update Test</button>
                <a href="<?php echo e(route('tests.index')); ?>" class="px-6 py-3 bg-gray-100 text-gray-700 rounded-xl">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\pathlas\resources\views/tests/edit.blade.php ENDPATH**/ ?>