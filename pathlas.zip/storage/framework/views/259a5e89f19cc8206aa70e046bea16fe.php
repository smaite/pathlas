
<?php $__env->startSection('title', 'Patients'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <div>
        <form action="<?php echo e(route('patients.index')); ?>" method="GET" class="flex gap-3">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search patients..." 
                class="px-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent w-64">
            <button type="submit" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200">Search</button>
        </form>
    </div>
    <a href="<?php echo e(route('patients.create')); ?>" class="px-4 py-2 bg-primary-600 text-white rounded-xl font-medium hover:bg-primary-700 flex items-center gap-2">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
        Add Patient
    </a>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Patient ID</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Name</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Age/Gender</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Phone</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Registered</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 font-mono text-sm"><?php echo e($patient->patient_id); ?></td>
                <td class="px-6 py-4 font-medium"><?php echo e($patient->name); ?></td>
                <td class="px-6 py-4"><?php echo e($patient->age); ?> / <?php echo e(ucfirst($patient->gender)); ?></td>
                <td class="px-6 py-4"><?php echo e($patient->phone); ?></td>
                <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($patient->created_at->format('M d, Y')); ?></td>
                <td class="px-6 py-4">
                    <div class="flex gap-2">
                        <a href="<?php echo e(route('patients.show', $patient)); ?>" class="px-3 py-1.5 bg-gray-100 text-gray-700 text-sm rounded-lg hover:bg-gray-200">View</a>
                        <a href="<?php echo e(route('bookings.create', ['patient_id' => $patient->id])); ?>" class="px-3 py-1.5 bg-primary-50 text-primary-600 text-sm rounded-lg hover:bg-primary-100">Book</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="px-6 py-8 text-center text-gray-500">No patients found</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-6"><?php echo e($patients->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\pathlas\resources\views/patients/index.blade.php ENDPATH**/ ?>