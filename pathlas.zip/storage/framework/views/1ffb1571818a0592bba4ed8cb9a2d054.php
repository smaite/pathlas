
<?php $__env->startSection('title', 'Super Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Stats -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Total Labs</p>
                    <p class="text-3xl font-bold text-gray-800"><?php echo e($stats['total_labs']); ?></p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
                    </svg>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Pending Verification</p>
                    <p class="text-3xl font-bold text-yellow-600"><?php echo e($stats['pending_labs']); ?></p>
                </div>
                <div class="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
                    <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Active Subscriptions</p>
                    <p class="text-3xl font-bold text-green-600"><?php echo e($stats['active_subscriptions']); ?></p>
                </div>
                <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Expired</p>
                    <p class="text-3xl font-bold text-red-600"><?php echo e($stats['expired_subscriptions']); ?></p>
                </div>
                <div class="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                    <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Pending Verifications -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100">
            <div class="p-6 border-b border-gray-100">
                <h3 class="font-semibold text-lg">Pending Verifications</h3>
            </div>
            <div class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $pendingLabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="p-4 flex items-center justify-between">
                    <div>
                        <p class="font-medium"><?php echo e($lab->name); ?></p>
                        <p class="text-sm text-gray-500"><?php echo e($lab->city); ?>, <?php echo e($lab->state); ?> • <?php echo e($lab->created_at->diffForHumans()); ?></p>
                    </div>
                    <div class="flex gap-2">
                        <form action="<?php echo e(route('superadmin.verify-lab', $lab)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="px-3 py-1 bg-green-100 text-green-700 rounded-lg text-sm hover:bg-green-200">Verify</button>
                        </form>
                        <a href="<?php echo e(route('superadmin.lab-details', $lab)); ?>" class="px-3 py-1 bg-gray-100 text-gray-700 rounded-lg text-sm">View</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-6 text-center text-gray-500">No pending verifications</div>
                <?php endif; ?>
            </div>
            <?php if($stats['pending_labs'] > 5): ?>
            <div class="p-4 border-t">
                <a href="<?php echo e(route('superadmin.labs')); ?>?status=pending" class="text-primary-600 text-sm">View all pending →</a>
            </div>
            <?php endif; ?>
        </div>

        <!-- Expiring Soon -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100">
            <div class="p-6 border-b border-gray-100">
                <h3 class="font-semibold text-lg">Expiring Soon (7 days)</h3>
            </div>
            <div class="divide-y divide-gray-100">
                <?php $__empty_1 = true; $__currentLoopData = $expiringLabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="p-4 flex items-center justify-between">
                    <div>
                        <p class="font-medium"><?php echo e($lab->name); ?></p>
                        <p class="text-sm text-red-500">Expires <?php echo e($lab->subscription_expires_at->diffForHumans()); ?></p>
                    </div>
                    <a href="<?php echo e(route('superadmin.lab-details', $lab)); ?>" class="px-3 py-1 bg-primary-100 text-primary-700 rounded-lg text-sm">Extend</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="p-6 text-center text-gray-500">No labs expiring soon</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Recent Labs -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100">
        <div class="p-6 border-b border-gray-100 flex justify-between items-center">
            <h3 class="font-semibold text-lg">Recent Labs</h3>
            <a href="<?php echo e(route('superadmin.labs')); ?>" class="text-primary-600 text-sm">View All →</a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lab</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Location</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subscription</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Registered</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__currentLoopData = $recentLabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4">
                            <a href="<?php echo e(route('superadmin.lab-details', $lab)); ?>" class="font-medium text-primary-600 hover:underline"><?php echo e($lab->name); ?></a>
                            <p class="text-xs text-gray-500"><?php echo e($lab->code); ?></p>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($lab->city); ?>, <?php echo e($lab->state); ?></td>
                        <td class="px-6 py-4">
                            <?php if($lab->is_verified): ?>
                            <span class="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">Verified</span>
                            <?php else: ?>
                            <span class="px-2 py-1 text-xs bg-yellow-100 text-yellow-700 rounded-full">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 text-xs <?php echo e($lab->subscription_badge); ?> rounded-full">
                                <?php echo e(ucfirst(str_replace('_', ' ', $lab->subscription_status))); ?>

                            </span>
                            <?php if($lab->days_remaining !== null): ?>
                            <span class="text-xs text-gray-500 ml-1"><?php echo e($lab->days_remaining); ?>d</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($lab->created_at->format('M d, Y')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\pathlas\resources\views/superadmin/dashboard.blade.php ENDPATH**/ ?>