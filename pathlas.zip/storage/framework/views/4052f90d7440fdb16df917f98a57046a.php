
<?php $__env->startSection('title', 'Activity Logs'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <form action="<?php echo e(route('activity-logs')); ?>" method="GET" class="flex gap-3">
        <select name="user_id" class="px-4 py-2 border border-gray-200 rounded-xl">
            <option value="">All Users</option>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>" <?php echo e(request('user_id') == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="date" name="date" value="<?php echo e(request('date')); ?>" class="px-4 py-2 border border-gray-200 rounded-xl">
        <button type="submit" class="px-4 py-2 bg-gray-100 rounded-xl hover:bg-gray-200">Filter</button>
    </form>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Time</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">User</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Action</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Details</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($log->created_at->format('M d, Y h:i A')); ?></td>
                <td class="px-6 py-4"><?php echo e($log->user?->name ?? 'System'); ?></td>
                <td class="px-6 py-4"><span class="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded"><?php echo e(str_replace('_', ' ', $log->action)); ?></span></td>
                <td class="px-6 py-4 text-sm text-gray-600"><?php echo e($log->model_type ? class_basename($log->model_type) . ' #' . $log->model_id : '-'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="4" class="px-6 py-8 text-center text-gray-500">No activity logs found</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-6"><?php echo e($logs->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\pathlas\resources\views/users/activity-logs.blade.php ENDPATH**/ ?>