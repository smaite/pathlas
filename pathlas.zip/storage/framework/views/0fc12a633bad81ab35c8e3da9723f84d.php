
<?php $__env->startSection('title', 'Pending Approvals'); ?>
<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
    <div class="px-6 py-4 border-b border-gray-100">
        <h2 class="text-lg font-semibold">Results Awaiting Approval</h2>
    </div>
    <table class="w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Patient</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Test</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Result</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Entered By</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Action</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $pendingResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4">
                    <p class="font-medium"><?php echo e($result->bookingTest->booking->patient->name); ?></p>
                    <p class="text-sm text-gray-500"><?php echo e($result->bookingTest->booking->booking_id); ?></p>
                </td>
                <td class="px-6 py-4"><?php echo e($result->bookingTest->test->name); ?></td>
                <td class="px-6 py-4">
                    <span class="font-mono"><?php echo e($result->value); ?></span>
                    <?php if($result->flag && $result->flag !== 'normal'): ?>
                    <span class="ml-2 px-2 py-0.5 rounded text-xs font-bold <?php echo e($result->flag_badge); ?>"><?php echo e($result->flag_label); ?></span>
                    <?php endif; ?>
                </td>
                <td class="px-6 py-4 text-sm"><?php echo e($result->enteredBy?->name ?? 'N/A'); ?></td>
                <td class="px-6 py-4">
                    <div class="flex gap-2">
                        <form action="<?php echo e(route('approvals.approve', $result)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="px-3 py-1.5 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700">Approve</button>
                        </form>
                        <a href="<?php echo e(route('approvals.show', $result->bookingTest->booking)); ?>" class="px-3 py-1.5 bg-gray-100 text-gray-700 text-sm rounded-lg hover:bg-gray-200">Review</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="px-6 py-8 text-center text-gray-500">No results pending approval! 🎉</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-6"><?php echo e($pendingResults->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\pathlas\resources\views/approvals/index.blade.php ENDPATH**/ ?>