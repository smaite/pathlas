
<?php $__env->startSection('title', 'Patient: ' . $patient->name); ?>
<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="lg:col-span-1">
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <div class="text-center mb-6">
                <div class="w-20 h-20 bg-gradient-to-br from-primary-500 to-indigo-600 rounded-2xl mx-auto flex items-center justify-center text-white text-2xl font-bold">
                    <?php echo e(substr($patient->name, 0, 1)); ?>

                </div>
                <h2 class="text-xl font-bold mt-4"><?php echo e($patient->name); ?></h2>
                <p class="text-gray-500"><?php echo e($patient->patient_id); ?></p>
            </div>
            <div class="space-y-4">
                <div class="flex justify-between"><span class="text-gray-500">Age</span><span class="font-medium"><?php echo e($patient->age); ?> years</span></div>
                <div class="flex justify-between"><span class="text-gray-500">Gender</span><span class="font-medium capitalize"><?php echo e($patient->gender); ?></span></div>
                <div class="flex justify-between"><span class="text-gray-500">Phone</span><span class="font-medium"><?php echo e($patient->phone); ?></span></div>
                <?php if($patient->email): ?><div class="flex justify-between"><span class="text-gray-500">Email</span><span class="font-medium"><?php echo e($patient->email); ?></span></div><?php endif; ?>
                <?php if($patient->blood_group): ?><div class="flex justify-between"><span class="text-gray-500">Blood Group</span><span class="font-medium"><?php echo e($patient->blood_group); ?></span></div><?php endif; ?>
            </div>
            <div class="mt-6 flex gap-3">
                <a href="<?php echo e(route('patients.edit', $patient)); ?>" class="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-xl text-center hover:bg-gray-200">Edit</a>
                <a href="<?php echo e(route('bookings.create', ['patient_id' => $patient->id])); ?>" class="flex-1 px-4 py-2 bg-primary-600 text-white rounded-xl text-center hover:bg-primary-700">Book Test</a>
            </div>
        </div>
    </div>

    <div class="lg:col-span-2">
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100">
            <div class="px-6 py-4 border-b border-gray-100">
                <h2 class="text-lg font-semibold">Booking History</h2>
            </div>
            <div class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $patient->bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('bookings.show', $booking)); ?>" class="block px-6 py-4 hover:bg-gray-50">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="font-medium"><?php echo e($booking->booking_id); ?></p>
                            <p class="text-sm text-gray-500"><?php echo e($booking->created_at->format('M d, Y h:i A')); ?></p>
                            <div class="mt-2 flex flex-wrap gap-1">
                                <?php $__currentLoopData = $booking->bookingTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded"><?php echo e($bt->test->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="text-right">
                            <span class="px-2.5 py-1 rounded-full text-xs font-medium <?php echo e($booking->status_badge); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $booking->status))); ?></span>
                            <p class="mt-2 font-semibold">₹<?php echo e(number_format($booking->total_amount, 2)); ?></p>
                        </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="px-6 py-8 text-center text-gray-500">No bookings yet</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\pathlas\resources\views/patients/show.blade.php ENDPATH**/ ?>