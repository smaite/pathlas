
<?php $__env->startSection('title', 'Reports'); ?>
<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <form action="<?php echo e(route('reports.index')); ?>" method="GET" class="flex gap-3">
        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search..." class="px-4 py-2 border border-gray-200 rounded-xl w-48">
        <input type="date" name="date" value="<?php echo e(request('date')); ?>" class="px-4 py-2 border border-gray-200 rounded-xl">
        <button type="submit" class="px-4 py-2 bg-gray-100 rounded-xl hover:bg-gray-200">Filter</button>
    </form>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="w-full">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Report ID</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Patient</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Booking</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Generated</th>
                <th class="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 font-mono text-sm"><?php echo e($report->report_id); ?></td>
                <td class="px-6 py-4"><?php echo e($report->booking->patient->name); ?></td>
                <td class="px-6 py-4 text-sm"><?php echo e($report->booking->booking_id); ?></td>
                <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($report->generated_at?->format('M d, Y h:i A') ?? '-'); ?></td>
                <td class="px-6 py-4">
                    <div class="flex gap-2">
                        <a href="<?php echo e(route('reports.show', $report)); ?>" class="px-3 py-1.5 bg-gray-100 text-gray-700 text-sm rounded-lg hover:bg-gray-200">View</a>
                        <form action="<?php echo e(route('reports.regenerate', $report)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" onclick="return confirm('Regenerate this report?')" class="px-3 py-1.5 bg-yellow-100 text-yellow-700 text-sm rounded-lg hover:bg-yellow-200">Regenerate</button>
                        </form>
                        <a href="<?php echo e(route('reports.download', $report)); ?>" class="px-3 py-1.5 bg-primary-600 text-white text-sm rounded-lg hover:bg-primary-700">Download</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="px-6 py-8 text-center text-gray-500">No reports found</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="mt-6"><?php echo e($reports->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\pathlas\resources\views/reports/index.blade.php ENDPATH**/ ?>